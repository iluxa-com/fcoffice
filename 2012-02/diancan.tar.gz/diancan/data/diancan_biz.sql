INSERT INTO diancan_biz (`bid`, `name`, `phone`) VALUES('1', '香四方', '26613782或26613783或26633256');
INSERT INTO diancan_biz (`bid`, `name`, `phone`) VALUES('2', '味真源', '86079080或86358899');
INSERT INTO diancan_biz (`bid`, `name`, `phone`) VALUES('3', '湖南人家', '13430541522');