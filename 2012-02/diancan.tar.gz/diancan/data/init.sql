DROP TABLE IF EXISTS `diancan_biz`;
CREATE TABLE IF NOT EXISTS `diancan_biz` (
  `bid` int(10) unsigned NOT NULL auto_increment COMMENT 'BID',
  `name` varchar(100) NOT NULL COMMENT '商家名称',
  `phone` varchar(100) NOT NULL COMMENT '订餐电话',
  PRIMARY KEY  (`bid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='商家表';

DROP TABLE IF EXISTS `diancan_menu`;
CREATE TABLE IF NOT EXISTS `diancan_menu` (
  `mid` int(10) unsigned NOT NULL auto_increment COMMENT 'MID',
  `bid` int(10) unsigned NOT NULL COMMENT 'BID',
  `name` varchar(100) NOT NULL COMMENT '菜名',
  `style` tinyint(3) unsigned NOT NULL COMMENT '菜系',
  `hot` tinyint(3) unsigned NOT NULL COMMENT '辣度',
  `price` decimal(10,2) NOT NULL COMMENT '价格(元)',
  `count` int(10) unsigned NOT NULL COMMENT '次数',
  `time` int(10) unsigned NOT NULL COMMENT '添加时间',
  PRIMARY KEY  (`mid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='菜单表';

DROP TABLE IF EXISTS `diancan_order`;
CREATE TABLE IF NOT EXISTS `diancan_order` (
  `oid` int(10) unsigned NOT NULL auto_increment COMMENT 'OID',
  `mid` int(10) NOT NULL COMMENT 'MID',
  `ip` varchar(15) NOT NULL COMMENT 'IP',
  `time` int(10) unsigned NOT NULL COMMENT '订餐时间',
  PRIMARY KEY  (`oid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='订餐表';