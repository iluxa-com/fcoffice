<?php
require_once 'CSV.php';

$dataStr = file_get_contents('menu.csv');
$dataStr = iconv('GBK', 'UTF-8', $dataStr);
$csv = new CSV();

$dataArr = $csv->restoreData($dataStr);

function getBid($name) {
    switch ($name) {
        case '香四方':
            return 1;
        case '味真源':
            return 2;
        case '湖南人家':
            return 3;
        default :
            exit("{$name} undefined!");
    }
}

$sqlArr = array();
foreach ($dataArr as $row) {
    $bizName = $row[0];
    $name = $row[1];
    $price = $row[2];
    if (!is_numeric($price)) {
        continue;
    }
    $bid = getBid($bizName);
    $style = 0;
    $hot = 0;
    $count = 0;
    $time = time();
    $sqlArr[] = "INSERT INTO diancan_menu (`bid`, `name`, `price`, `style`, `hot`, `count`, `time`) VALUES ('{$bid}', '{$name}', '{$price}', '{$style}', '{$hot}', '{$count}', '{$time}');";
}
echo implode("\r\n", $sqlArr);
?>