<?php
// 引入配置文件
require_once 'config_test.php';

$service = isset($_GET['service']) ? $_GET['service'] : 'DiancanService';
$action = isset($_GET['action']) ? $_GET['action'] : 'showMenuList';

// 输出内容编码设置
header('Content-Type: text/html; charset=utf-8');

// 服务调用
try {
    App::dispatch(1, $service, $action, NULL, 0);
} catch (Exception $e) { // 捕捉所有异常
    if (defined('DEBUG_MODE') && constant('DEBUG_MODE')) { // 调试模式,输出详细信息
        if ($e instanceof UserException) {
            exit($e);
        } else {
            exit($e->getTraceAsString());
        }
    } else { // 非调式模式,仅输出错误代码
        exit('{"ret":' . $e->getCode() . '}');
    }
}
?>