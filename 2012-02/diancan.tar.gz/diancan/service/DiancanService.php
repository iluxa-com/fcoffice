<?php

/**
 * 点餐服务类
 *
 * @author xianlinli@gmail.com
 * @package Alice
 */
class DiancanService extends Service {

    /**
     * 午餐点餐开始时间
     * @var int
     */
    private $_lunchStart;
    /**
     * 午餐点餐结束时间
     * @var int
     */
    private $_lunchEnd;
    /**
     * 晚餐点餐开始时间
     * @var int
     */
    private $_supperStart;
    /**
     * 晚餐点餐结束时间
     * @var int
     */
    private $_supperEnd;
    /**
     * 管理员IP地址
     * @var array
     */
    private $_adminIp;

    /**
     * 构造函数
     * @param array $configArr
     */
    public function __construct($configArr) {
        $today = strtotime('today', CURRENT_TIME);
        $this->_lunchStart = $today + 9 * 60 * 60;
        $this->_lunchEnd = $today + 9 * 60 * 60;
        $this->_supperStart = $today + 15 * 60 * 60;
        $this->_supperEnd = $today + 17.5 * 60 * 60;
        $this->_adminIp = array(
            '192.168.0.23',
            '192.168.0.41',
            '192.168.1.4',
            '192.168.0.68',
            '192.168.0.104',
            '192.168.1.57', 
        );
    }

    /**
     * 显示商家添加页面
     */
    public function showBizAdd() {
        $this->_data['filename'] = 'biz_show_add.php';
    }

    /**
     * 执行添加商家
     */
    public function doBizAdd() {
        $dataArr = $_POST;
        $name = $dataArr['name'];
        if (!is_string($name) || $name === '') {
            $this->_data['focus'] = '#name';
            $this->_data['msg'] = '＠＿＠，请填写正确的商家名称！';
            return;
        }
        $phone = $dataArr['phone'];
        if (!is_string($phone) || $phone === '') {
            $this->_data['focus'] = '#phone';
            $this->_data['msg'] = '＠＿＠，请填写正确的订餐电话！';
            return;
        }
        $bizSQLModel = new BizSQLModel();
        $name = $dataArr['name'];
        $count = $bizSQLModel->SH()->find(array('name' => $name))->count();
        if ($count > 0) {
            $this->_data['focus'] = '#name';
            $this->_data['msg'] = '＠＿＠，商家[' . $name . ']已存在！';
            return;
        }
        unset($dataArr['bid']);
        $bizSQLModel->SH()->insert($dataArr);
        $this->_data['msg'] = '*^_^*，添加成功！';
        $this->_ret = 0;
    }

    /**
     * 显示菜单添加页面
     */
    public function showMenuAdd() {
        $bizSQLModel = new BizSQLModel();
        $bizDataArr = $bizSQLModel->SH()->orderBy(array('bid' => 'ASC'))->getAll();
        $this->_data = array(
            'filename' => 'menu_show_add.php',
            'biz' => $bizDataArr,
        );
    }

    /**
     * 执行菜单添加
     */
    public function doMenuAdd() {
        $dataArr = $_POST;
        $name = $dataArr['name'];
        if (!is_string($name) || $name === '') {
            $this->_data['focus'] = '#name';
            $this->_data['msg'] = '＠＿＠，请填写正确的菜名！';
            return;
        }
        $price = $dataArr['price'];
        if (!is_numeric($price) || $price < 0) {
            $this->_data['focus'] = '#price';
            $this->_data['msg'] = '＠＿＠，请填写正确的单价！';
            return;
        }
        $bid = $dataArr['bid'];
        if ($bid == 0) {
            $this->_data['focus'] = '#bid';
            $this->_data['msg'] = '＠＿＠，请选择商家！';
            return;
        }
        $dataArr['count'] = 0;
        $dataArr['time'] = time();
        //$dataArr['date_time'] = date("Y-m-d H:i:s");
        $menuSQLModel = new MenuSQLModel();
        $name = $dataArr['name'];
        $count = $menuSQLModel->SH()->find(array('bid' => $dataArr['bid'], 'name' => $name))->count();
        if ($count > 0) {
            $this->_data['focus'] = '#name';
            $this->_data['msg'] = '＠＿＠，菜品[' . $name . ']已经存在所选的商家中！';
            return;
        }
        unset($dataArr['mid']);
        $menuSQLModel->SH()->insert($dataArr);
        $this->_data['msg'] = '*^_^*，添加成功！';
        $this->_ret = 0;
    }

    /**
     * 显示菜单更新页面
     */
    public function showMenuUpdate() {
        $bizSQLModel = new BizSQLModel();
        $bizDataArr = $bizSQLModel->SH()->orderBy(array('bid' => 'ASC'))->getAll();
        $mid = isset($_GET['id']) ? $_GET['id'] : '';
        $menuSQLModel = new MenuSQLModel();
        $dataArr = $menuSQLModel->SH()->find(array('mid' => $mid))->getOne();
        $this->_data = array(
            'filename' => 'menu_show_update.php',
            'biz' => $bizDataArr,
            'data' => $dataArr,
        );
        $this->_ret = 0;
    }

    /**
     * 执行菜单更新
     */
    public function doMenuUpdate() {
        $mid = isset($_GET['id']) ? $_GET['id'] : '';
        $dataArr = $_POST;
        $name = $dataArr['name'];
        if (!is_string($name) || $name === '') {
            $this->_data['focus'] = '#name';
            $this->_data['msg'] = '＠＿＠，请填写正确的菜名！';
            return;
        }
        $price = $dataArr['price'];
        if (!is_numeric($price) || $price < 0) {
            $this->_data['focus'] = '#price';
            $this->_data['msg'] = '＠＿＠，请填写正确的单价！';
            return;
        }
        $menuSQLModel = new MenuSQLModel();
        $menuSQLModel->SH()->find(array('mid' => $mid))->update($dataArr);
        $this->_data = array(
            'msg' => '*^_^*，修改成功！',
            'back' => true,
        );
        $this->_ret = 0;
    }

    /**
     * 显示菜单列表
     */
    public function showMenuList() {
        $bizSQLModel = new BizSQLModel();

        //增加 星期几 的餐馆限制
        $week = date('w');
        if ($week == 0) {
            $week = 7;
        }
        $week_rs = $bizSQLModel->SH()->find(array('like' => array('week' => "%$week%")))->getOne();
        $arr_week = array();
        if (!empty($week_rs['bid'])) {
            $arr_week = array('bid' => $week_rs['bid']);
        }

        $bizDataArr = $bizSQLModel->SH()->find($arr_week)->getAll();
        $bizNameArr = array();
        foreach ($bizDataArr as $row) {
            $bizNameArr[$row['bid']] = $row['name'];
        }
        $page = isset($_GET['page']) ? $_GET['page'] : 1;
        $orderColumn = isset($_GET['orderColumn']) ? $_GET['orderColumn'] : 'mid';
        $orderMethod = isset($_GET['orderMethod']) ? $_GET['orderMethod'] : 'ASC';
        $whereArr = isset($_GET['filter']) ? $_GET['filter'] : array();


        $whereArr = array_merge($whereArr, $arr_week); //增加 星期几 的餐馆限制

        $queryArr = array();
        foreach ($whereArr as $key => $val) {
            $queryArr[] = urlencode('filter[' . $key . ']') . '=' . urlencode($val);
        }
        $pageSize = 15;
        $menuSQLModel = new MenuSQLModel();
        $count = $menuSQLModel->SH()->find($whereArr)->count();
        $totalPage = ceil($count / $pageSize);
        $page = max(1, min($page, $totalPage));
        $pageOffset = ($page - 1) * $pageSize;
        $this->_data = array(
            'filename' => 'menu_show_list.php',
            'biz' => $bizNameArr,
            'filter' => $whereArr,
            'q' => empty($queryArr) ? '' : '&' . implode('&', $queryArr),
            'page' => $page,
            'count' => $count,
            'pageSize' => $pageSize,
            'totalPage' => $totalPage,
            'orderColumn' => $orderColumn,
            'orderMethod' => $orderMethod,
            'data' => $menuSQLModel->SH()->find($whereArr)->orderBy(array($orderColumn => $orderMethod))->limit($pageOffset, $pageSize)->getAll(),
        );
        $this->_ret = 0;
    }

    /**
     * 删除菜单
     */
    public function doMenuDelete() {
        $mid = isset($_GET['id']) ? $_GET['id'] : '';
        $ip = $this->__getIP();

        if (!in_array($ip, $this->_adminIp)) {
            $this->_data['msg'] = '＠＿＠，你没有权限！';
            return;
        }
        $menuSQLModel = new MenuSQLModel();
        $menuSQLModel->SH()->find(array('mid' => $mid))->delete();
        $this->_data['msg'] = '删除成功！';
        return;
    }

    /**
     * 订餐
     */
    public function doOrderBook() {
        $mid = isset($_GET['id']) ? $_GET['id'] : '';
        $ip = $this->__getIP();
        $ip_arr = explode('.', $ip);
        if ($ip_arr[3] > 100) {
            $ip_arr[2] = intval($ip_arr[3] / 100);
            $ip_arr[3] = $ip_arr[3] % 100;
            $newIp = implode('.', $ip_arr);
            $this->_data['msg'] = '＠＿＠，你IP地址' . $ip . ' 设置错误，请更改成' . $newIp . '！';
            return;
        }
        $orderSQLModel = new OrderSQLModel();
        if (CURRENT_TIME >= $this->_lunchStart && CURRENT_TIME < $this->_lunchEnd) {
            $whereArr = array(
                'ip' => $ip,
                '>=' => array(
                    'time' => $this->_lunchStart,
                ),
                '<' => array(
                    'time' => $this->_lunchEnd,
                ),
            );
            $count = $orderSQLModel->SH()->find($whereArr)->count();
            if ($count > 0) {
                $this->_data['msg'] = '＠＿＠，你已经点过午餐了！';
                return;
            }
        } else if (CURRENT_TIME >= $this->_supperStart && CURRENT_TIME < $this->_supperEnd) {
            $whereArr = array(
                'ip' => $ip,
                '>=' => array(
                    'time' => $this->_supperStart,
                ),
                '<' => array(
                    'time' => $this->_supperEnd,
                ),
            );
            $count = $orderSQLModel->SH()->find($whereArr)->count();
            if ($count > 0) {
                $this->_data['msg'] = '＠＿＠，你已经点过晚餐了！';
                return;
            }
        } else {
            $this->_data['msg'] = '＠＿＠，还没到点餐时间段或点餐时间段已过了！';
            return;
        }
        $dataArr = array(
            'mid' => $mid,
            'ip' => $ip,
            'time' => time(),
            'date_time' => date("Y-m-d H:i:s"),
        );
        $orderSQLModel->SH()->insert($dataArr);
        $menuSQLModel = new MenuSQLModel();
        $menuSQLModel->SH()->find(array('mid' => $mid))->update(array('+' => array('count' => 1)));
        $paramArr = array(
            'mid' => $mid,
            'msg' => '*^_^*，点餐成功！',
        );
        $this->_data = array(
            'callback' => 'orderCallback',
            'params' => json_encode($paramArr),
        );
        $this->_ret = 0;
    }

    /**
     * 显示订餐列表
     */
    public function showOrderList() {
        $ip = $this->__getIP();
        $nameArr = $this->__getUserId();

        $bizSQLModel = new BizSQLModel();
        $bizDataArr = $bizSQLModel->SH()->getAll();
        $bizNameArr = array();
        foreach ($bizDataArr as $row) {
            $bizNameArr[$row['bid']] = $row;
        }
        $menuSQLModel = new MenuSQLModel();
        $menuDataArr = $menuSQLModel->SH()->getAll();
        $tempArr = array();
        foreach ($menuDataArr as $row) {
            $tempArr[$row['mid']] = $row;
        }
        $hour = intval(date('H', CURRENT_TIME));
        if ($hour < 14) {
            $whereArr = array(
                '>=' => array(
                    'time' => $this->_lunchStart,
                ),
                '<' => array(
                    'time' => $this->_lunchEnd,
                ),
            );
        } else {
            $whereArr = array(
                '>=' => array(
                    'time' => $this->_supperStart,
                ),
                '<' => array(
                    'time' => $this->_supperEnd,
                ),
            );
        }
        $orderSQLModel = new OrderSQLModel();
        $dataArr = $orderSQLModel->SH()->find($whereArr)->orderBy(array('time' => 'ASC'))->getAll();

        $day = date('Y-m-d', CURRENT_TIME);
        $hour = intval(date('H', CURRENT_TIME));
        $type = ($hour < 14) ? 0 : 1;
        $fetchSQLModel = new FetchSQLModel();
        $whereArr = array(
            'day' => $day,
            'type' => $type,
        );
        $row = $fetchSQLModel->SH()->find($whereArr)->fields('ip')->getOne();


        $is_admin = 0;
        $ip = $this->__getIP();
        if (in_array($ip, $this->_adminIp)) {
            $is_admin = 1;
        }
        
        $this->_data = array(
            'filename' => 'order_show_list.php',
            'biz' => $bizNameArr,
            'menu' => $tempArr,
            'ip' => $ip,
            'data' => $dataArr,
            'nameArr' => $nameArr,
            'fetch' => $row,
            'is_admin' => $is_admin,
        );
        $this->_ret = 0;
    }

    /**
     * 显示用户
     */
    public function showUser() {
        $is_admin = 0;
        $ip = $this->__getIP();
        if (in_array($ip, $this->_adminIp)) {
            $is_admin = 1;
        }
        if ($is_admin == 1 && !empty($_POST['user']['u_no']) && !empty($_POST['user']['u_name'])) {
            $userSQLModel = new UserSQLModel();
            $userSQLModel->SH()->insert($_POST['user']);
        }
        if ($is_admin == 1 && !empty($_POST['del'])) {
            $userSQLModel = new UserSQLModel();
            $userSQLModel->SH()->find(array('u_no' => trim($_POST['del'])))->delete();
        }
        $nameArr = $this->__getUserId();
        $this->_data = array(
            'filename' => 'order_show_user.php',
            'nameArr' => $nameArr,
            'is_admin' => $is_admin,
        );
        $this->_ret = 0;
    }

    /**
     * 更新点餐备注
     */
    public function doUpdateNote() {
        $oid = $_GET['id'];
        $note = $_GET['note'];
        $ip = $this->__getIP();
        $dataArr = array(
            'note' => $note,
        );
        $orderSQLModel = new OrderSQLModel();
        $count = $orderSQLModel->SH()->find(array('oid' => $oid, 'ip' => $ip))->count();
        if ($count == 0) {
            $this->_data['msg'] = '＠＿＠，别人订的餐，你不能帮TA更新备注！';
            return;
        }
        $orderSQLModel->SH()->find(array('oid' => $oid, 'ip' => $ip))->update($dataArr);
        $this->_data['msg'] = '*^_^*，备注更新成功！';
        $this->_ret = 0;
    }

    /**
     * 随机抽取取餐人
     */
    public function randFetchUser() {
        $ip = $this->__getIP();
        if (!in_array($ip, $this->_adminIp)) {
            $this->_data['msg'] = '＠＿＠，你没有权限！';
            return;
        }
        $day = date('Y-m-d', CURRENT_TIME);
        $hour = intval(date('H', CURRENT_TIME));
        $type = ($hour < 14) ? 0 : 1;
        $fetchSQLModel = new FetchSQLModel();
        $whereArr = array(
            'day' => $day,
            'type' => $type,
        );
        $row = $fetchSQLModel->SH()->find($whereArr)->getOne();
        if ($row !== false) {
            $this->_data['msg'] = '＠＿＠，已经设置过！';
            return;
        }
        if ($type == 0) {
            $whereArr = array(
                '>=' => array(
                    'time' => $this->_lunchStart,
                ),
                '<' => array(
                    'time' => $this->_lunchEnd,
                ),
            );
        } else {
            $whereArr = array(
                '>=' => array(
                    'time' => $this->_supperStart,
                ),
                '<' => array(
                    'time' => $this->_supperEnd,
                ),
            );
        }
        $orderSQLModel = new OrderSQLModel();
        $dataArr = $orderSQLModel->SH()->find($whereArr)->fields('ip')->orderBy(array('time' => 'ASC'))->getAll();
        $indexArr = array_rand($dataArr, ceil(count($dataArr) / 5));
        if (!is_array($indexArr)) {
            $indexArr = array($indexArr);
        }
        $ipArr = array();
        foreach ($indexArr as $index) {
            $ipArr[] = $dataArr[$index]['ip'];
        }
        $dataArr = array(
            'day' => $day,
            'type' => $type,
            'ip' => implode(',', $ipArr),
        );
        $fetchSQLModel->SH()->insert($dataArr);
        header('Location: ?service=DiancanService&action=showOrderList');
        $this->_ret = 0;
    }

    /**
     * 更新点餐备注2
     */
    public function doUpdateNote2() {
        $ip = $this->__getIP();

        if (!in_array($ip, $this->_adminIp)) {
            $this->_data['msg'] = '＠＿＠，你没有权限！';
            return;
        }
        $oid = $_GET['id'];
        $note2 = $_GET['note2'];
        $ip = $this->__getIP();
        $dataArr = array(
            'note2' => $note2,
        );
        $orderSQLModel = new OrderSQLModel();
        $count = $orderSQLModel->SH()->find(array('oid' => $oid))->count();
        if ($count == 0) {
            $this->_data['msg'] = '＠＿＠，别人订的餐，你不能帮TA更新备注！';
            return;
        }
        $orderSQLModel->SH()->find(array('oid' => $oid))->update($dataArr);
        $this->_data['msg'] = '*^_^*，备注更新成功！';
        $this->_ret = 0;
    }

    /**
     * 取消订餐
     */
    public function doOrderCancel() {
        $oid = isset($_GET['id']) ? $_GET['id'] : '';
        $ip = $this->__getIP();
        $orderSQLModel = new OrderSQLModel();
        $dataArr = $orderSQLModel->SH()->find(array('oid' => $oid, 'ip' => $ip))->getOne();
        if (empty($dataArr)) {
            $this->_data['msg'] = '＠＿＠，别人订的餐，你不能帮TA取消！';
            return;
        }
        if (CURRENT_TIME < $this->_lunchStart || CURRENT_TIME > $this->_supperEnd || ( CURRENT_TIME < $this->_lunchEnd && CURRENT_TIME > $this->_supperStart)) {
            $this->_data['msg'] = '已经超过点餐时间，不能取消！';
            return;
        }
        $orderSQLModel->SH()->find(array('oid' => $oid, 'ip' => $ip))->delete();
        $menuSQLModel = new MenuSQLModel();
        $tempArr = $menuSQLModel->SH()->find(array('mid' => $dataArr['mid']))->getOne();
        if ($tempArr['count'] > 1) {
            $menuSQLModel->SH()->find(array('mid' => $dataArr['mid']))->update(array('-' => array('count' => 1)));
        }
        $paramArr = array(
            'oid' => $oid,
            'msg' => '*^_^*，点餐取消成功！',
        );
        $this->_data = array(
            'callback' => 'orderCancelCallback',
            'params' => json_encode($paramArr),
        );
        $this->_ret = 0;
    }

    /**
     * 显示通知页面
     */
    public function showNotice() {
        $this->_data['filename'] = 'notice_show.php';
    }

    /**
     * 获取访问者IP
     * @return string
     */
    private function __getIP() {
        // 此顺序不要更改
        $keyArr = array('HTTP_CLIENT_IP', 'HTTP_X_FORWARDED_FOR', 'REMOTE_ADDR');
        foreach ($keyArr as $key) {
            if (!isset($_SERVER[$key])) {
                continue;
            }
            $ip = $_SERVER[$key];
            if (!empty($ip)) {
                return $ip;
            }
        }
        return '0.0.0.0';
    }

    /**
     * 获取 公司员工编号 和姓名
     * @return string
     */
    private function __getUserId() {
        $userSQLModel = new UserSQLModel();
        $rs = $userSQLModel->SH()->getAll();
        if (!empty($rs)) {
            foreach ($rs as $val) {
                $arr[$val['u_no']] = $val['u_name'];
            }
        }
        return $arr;
    }

    /**
     * 设置每日点餐商家
     */
    public function week() {
        $bizSQLModel = new BizSQLModel();
        $ip = $this->__getIP();
        $this->_data['admin'] = '0';
        if (in_array($ip, $this->_adminIp)) {
            $this->_data['admin'] = '1';

            if (!empty($_POST['week'])) {
                for ($i = 1; $i < 8; $i++) {

                    $arr[$_POST['week'][$i]][] = $i;
                }
                $bizSQLModel->SH()->update(array('week' => ''));
                foreach ($arr as $k => $v) {
                    $up = implode(',', $arr[$k]);
                    $bizSQLModel->SH()->find(array('bid' => $k))->update(array('week' => $up));
                }
            }
        }
        $rs = $bizSQLModel->SH()->find(array('deleted' => 0))->getAll();

        if (!empty($rs)) {
            foreach ($rs as $val) {
                if (!empty($val['week'])) {
                    $week = explode(',', $val['week']);
                    foreach ($week as $v) {
                        $week_biz[$v] = $val['bid'];
                    }
                }
                $bid[$val['bid']] = $val['name'];
            }
        }
        $this->_data['filename'] = 'week.php';
        $this->_data['week_biz'] = $week_biz;
        $this->_data['week'] = date('w');
        $this->_data['bid'] = $bid;

        $this->_ret = 0;
    }

}

?>
