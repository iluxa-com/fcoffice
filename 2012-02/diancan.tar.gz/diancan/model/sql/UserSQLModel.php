<?php
/**
 * 商家SQL模型类
 *
 * @author xianlinli@gmail.com
 * @package Alice
 */
class UserSQLModel extends SQLModel {
    /**
     * 服务器组
     * @var string
     */
    protected $_serverGroup = 'MySQL_Main_Server';
    /**
     * 表名
     * @var string
     */
    protected $_tableName = 'diancan_user';
}
?>