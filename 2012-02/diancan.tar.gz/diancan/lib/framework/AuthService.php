<?php
/**
 * 认证服务类
 *
 * @author xianlinli@gmail.com
 */
abstract class AuthService extends Service {
    /**
     * 构造函数
     * @param array $configArr array($service, $action, $index)
     */
    public function __construct($configArr) {
        // 在这里进行认证(预留)
        parent::__construct($configArr);
    }
}
?>