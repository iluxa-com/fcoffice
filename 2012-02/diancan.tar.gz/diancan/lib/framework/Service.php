<?php
/**
 * 服务基类
 *
 * @author xianlinli@gmail.com
 * @package Alice
 */
abstract class Service {
    /**
     * 互斥时间(秒)
     * @var float
     */
    protected $_mutexTime = 2.5;
    /**
     * 互斥过期时间
     * @var float
     */
    private $_mutexExpire;
    /**
     * 互斥模型实例
     * @var MutexModel
     */
    private $_mutexModel;
    /**
     * 当前用户信息
     * @var array
     */
    protected $_currentUser;
    /**
     * 当前登录用户的用户ID
     * @var int
     */
    protected $_userId;
    /**
     * 用户模型实例
     * @var UserModel
     */
    protected $_userModel;
    /**
     * 数据数组(必须为数组,默认为空数组)
     * @var array
     */
    protected $_data = array();
    /**
     * 返回代码(默认为-1)
     * @var int
     */
    protected $_ret = -1;
    /**
     * 服务调用序号
     * @var int
     */
    protected $_index = -1;

    /**
     * 输出服务结果并终止脚本
     * @param int $entry 入口
     */
    final public function outputResult($entry) {
        if ($entry === 0) {
            exit(json_encode(array_merge(array('ret' => $this->_ret, 'index' => $this->_index), $this->_data)));
        } else if (isset($this->_data['filename'])) {
            $D = $this->_data;
            require_once BASE_DIR . DS . 'admin' . DS . 'loader.php';
            exit;
        } else {
            exit(json_encode(array_merge(array('ret' => $this->_ret, 'index' => $this->_index), $this->_data)));
        }
    }
}
?>