<?php
/**
 * 用户异常类
 *
 * @author xianlinli@gmail.com
 * @package Alice
 */
class UserException extends Exception {
    /**
     * 系统错误
     * @var int
     */
    const ERROR_SYSTEM = 100;
    /**
     * 登录超时
     * @var int
     */
    const ERROR_LOGIN_TIMEOUT = 101;
    /**
     * 帐号被屏蔽
     * @var int
     */
    const ERROR_ACCOUNT_BLOCKED = 102;

    /**
     * 构造函数
     * @param int $code 错误编号
     * @param string $format 错误消息格式字符串
     * @param mixed $arg1,$arg2,... 可变参数(格式参数)
     */
    public function __construct($code = -1, $format = 'UNDEFINED_ERROR') {
        // 获取参数数组
        $args = func_get_args();
        // 移去第一个参数
        array_shift($args);
        // 移去第二个参数
        array_shift($args);
        // 解析错误消息格式字符串配置到数组
        $formatArr = parse_ini_file(CONF_DIR . DIRECTORY_SEPARATOR . 'Msg.php');
        // 格式化消息
        if (is_array($formatArr) && array_key_exists($format, $formatArr)) {
            $msg = vsprintf($formatArr[$format], $args);
        } else {
            $msg = vsprintf($format, $args);
        }
        // 调用父类的构造函数
        parent::__construct($msg, $code);
    }

    /**
     * 重载__toString()方法
     * @return string
     */
    public function __toString() {
        $str = '';
        $str .= '<pre>';
        $str .= "\n";
        $str .= __CLASS__;
        $str .= "\n";
        $str .= $this->getCode();
        $str .= "\n";
        $str .= $this->getFile() . '(' . $this->getLine() . ')';
        $str .= "\n";
        $str .= $this->getMessage();
        $str .= "\n";
        $str .= $this->getTraceAsString();
        return $str;
    }
}
?>