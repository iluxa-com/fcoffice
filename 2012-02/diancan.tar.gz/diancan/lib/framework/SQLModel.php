<?php
/**
 * SQL模型类
 *
 * @author xianlinli@gmail.com
 * @package Alice
 */
abstract class SQLModel {
    /**
     * Cache驱动名称(MemcachedHelper/MemcacheHelper)
     * @var string
     */
    private $_cacheDriver = 'MemcachedHelper';
    /**
     * Cache辅助类的实例数组
     * @var array
     */
    private static $_cacheHelper = array();
    /**
     * DB驱动名称(MySQLHelper/MySQLiHelper/PDOHelper)
     * @var string
     */
    private $_dbDriver = 'MySQLHelper';
    /**
     * DB辅助类的实例数组
     * @var array
     */
    private static $_dbHelper = array();
    /**
     * SQL驱动名称(SQLHelper)
     * @var string
     */
    private $_sqlDriver = 'SQLHelper';
    /**
     * SQL辅助类的实例数组
     * @var array
     */
    private static $_sqlHelper = array();
    /**
     * 是否启用Cache
     * @var bool
     */
    private $_enableCache = false;
    /**
     * 是否启用多表
     * @var bool
     */
    protected $_enableMultiTable = false;
    /**
     * 轮转ID
     * @var int
     */
    private $_circleId = 0;

    /**
     * 构造函数
     */
    public function __construct() {
        switch ($this->_serverGroup) {
            case 'MySQL_Main_Server':
                // 设置轮转ID(固定为0)
                $this->_circleId = 0;
                break;
            case 'MySQL_Circle_Server':
                // 设置轮转ID(取用户ID)
                $args = func_get_args();
                if (empty($args)) {
                    $this->_circleId = App::get('user_id');
                } else {
                    $this->_circleId = $args[0];
                }
                if ($this->_enableMultiTable) { // 启用多表时,重写表名
                    $this->_tableName .= sprintf('_%03d', $this->_circleId / 1000000);
                }
                break;
            default:
                throw new UserException(UserException::ERROR_SYSTEM, 'UNDEFINED_SERVER_GROUP', $this->_serverGroup);
                break;
        }
    }

    /**
     * 获取Cache辅助类的实例
     * @return MemcacheHelper
     */
    public function CH() {
        $configArr = App::getServerConfig('Cache_Server', $this->_circleId);
        $key = $configArr[0] . ':' . $configArr[1];
        if (!isset(self::$_cacheHelper[$key])) {
            self::$_cacheHelper[$key] = App::getInst($this->_cacheDriver, $configArr, false, $key);
        }
        return self::$_cacheHelper[$key];
    }

    /**
     * 获取DB辅助类的实例
     * @return MySQLHelper
     */
    public function DH() {
        $configArr = App::getServerConfig($this->_serverGroup, $this->_circleId);
        $key = $configArr[0] . ':' . $configArr[1];
        if (!isset(self::$_dbHelper[$key])) {
            self::$_dbHelper[$key] = App::getInst($this->_dbDriver, $configArr, false, $key);
        }
        return self::$_dbHelper[$key];
    }

    /**
     * 获取SQL辅助类的实例
     * @return SQLHelper
     */
    public function SH() {
        $configArr = App::getServerConfig($this->_serverGroup, $this->_circleId);
        $key = $configArr[0] . ':' . $configArr[1];
        if (!isset(self::$_sqlHelper[$key])) {
            self::$_sqlHelper[$key] = App::getInst($this->_sqlDriver, array($this->DH(), $this->_dbDriver), false, $key);
        }
        self::$_sqlHelper[$key]->database($configArr[4]); // 更新数据库名
        self::$_sqlHelper[$key]->table($this->_tableName); // 更新表名
        return self::$_sqlHelper[$key];
    }
}
?>