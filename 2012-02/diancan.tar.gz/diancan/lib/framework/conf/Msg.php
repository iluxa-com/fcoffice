;应用
ADD_VARIABLE_THAT_ALREADY_EXISTS	=	"试图添加已存在的变量(%s)"
GET_VARIABLE_THAT_NOT_EXISTS		=	"试图获取不存在的变量(%s)"
TRANSACTION_ALREADY_STARTED			=	"事务已经开启"
INVALID_SERVICE						=	"无效的服务(%s)"
SERVICE_CLASS_NOT_FOUND				=	"服务类(%s)未找到"
INVALID_PARAMS						=	"无效的动作参数"
ACTION_NOT_FOUND					=	"动作方法(%s)未找到"
EXTENSION_NOT_LOADED				=	"扩展模块(%s)未加载"
SERVER_IS_BUSY						=	"服务器繁忙"

;数据库
DB_ERROR_DETAIL						=	"Where:%s<br />Query:%s<br />Error:%s<br />Errno:%d"
DB_ERROR_SIMPLE						=	"%s"
UNKNOWN_UPDATE_KEY					=	"未知的更新数据Key(%s)"
UNKNOWN_WHERE_KEY					=	"未知的条件数据Key(%s)"

;模型
UNDEFINED_SERVER_GROUP				=	"未定义的服务器组(%s)"
SERVER_NODE_NOT_FOUND				=	"服务器节点(%d)未找到"

;Memcached
MEMCACHED_ERROR						=	"Memcached Error(code=%s)"