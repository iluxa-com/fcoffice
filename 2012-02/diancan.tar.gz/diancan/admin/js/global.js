// JavaScript Document
$(function () {
    $.extend({
        ajaxSuccessCallback: function (data, textStatus, xhr) {
            if (data.callback) {
                if (data.params) {
                    eval(data.callback + '(' + data.params + ')');
                } else {
                    eval(data.callback + '()');
                }
            } else if (data.msg) {
                alert(data.msg);
                if (data.back) {
                    history.go(-1);
                } else if (data.focus) {
                    $(data.focus).focus();
                }
            } else {
                alert(xhr.responseText);
            }
        },
        applyInputFilter: function () {
            $('input').die('keyup').live('keyup', function () {
                if ($(this).hasClass('positiveIntegerFilter')) {
                    var regExp = /[^0-9]/g; // 匹配非数字字符
                } else if ($(this).hasClass('negativeIntegerFilter')) {
                    var regExp = /[^0-9\-]/g; // 匹配非数字字符和非"-"字符
                } else if ($(this).hasClass('positiveFloatFilter')) {
                    var regExp = /[^0-9\.]/g; // 匹配非数字和非"."字符
                } else if ($(this).hasClass('negativeFloatFilter')) {
                    var regExp = /[^0-9\.\-]/g; // 匹配非数字、非"."和非"-"字符
                } else {
                    return;
                }
                var oldVal = $(this).val();
                var newVal = oldVal.replace(regExp, ''); // 将匹配的字符都替换成空串
                if (oldVal != newVal) {
                    $(this).val(newVal);
                }
            });
        }
    });
    $.fn.setupSubmit = function () {
        return this.each(function () {
            // 检查submit绑定标志,如果已经设置,直接返回true跳过
            if ($(this).data('submitBind')) {
                return true;
            }
            $(this).submit(function () {
                // 如果设置了验证回调函数,则先执行验证回调函数,验证回调函数返回true表示验证通过
                if ($(this).data('validateCallback') && typeof($(this).data('validateCallback')) == 'function' && !$(this).data('validateCallback')()) {
                    return false;
                }
                if ($(this).attr('method') && ($(this).attr('method').toLowerCase() == 'post')) {
                    $.post(
                        $(this).attr('action'), $(this).serialize(), $.ajaxSuccessCallback, 'json');
                } else {
                    $.get(
                        $(this).attr('action'), $(this).serialize(), $.ajaxSuccessCallback, 'json');
                }
                return false;
            });
            // 设置submit事件绑定标志
            $(this).data('submitBind', true);
        });
    };

    $('form.ajaxSubmit').setupSubmit();

    // hover样式应用
    $('table.gHover tr, ul.gHover li, ol.gHover li, dl.gHover dd').die('mouseover').live('mouseover', function () {
        $(this).addClass('hover');
    });
    $('table.gHover tr, ul.gHover li, ol.gHover li, dl.gHover dd').die('mouseout').live('mouseout', function () {
        $(this).removeClass('hover');
    });
    // 返回按钮单击事件绑定
    $('button.gGoBack').die('click').live('click', function () {
        self.history.go(-1);
    });
    // 输入框应用输入过滤
    $.applyInputFilter();

    $('.ajaxLink').die('click').live('click', function(){
        $.get($(this).attr('href'), '', $.ajaxSuccessCallback, 'json');
        return false;
    });
});