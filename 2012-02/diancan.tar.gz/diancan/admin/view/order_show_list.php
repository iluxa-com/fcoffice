<?php require_once 'header.php'; ?>
<div class="gMain">
  <table class="gTable gHover orderList" width="100%" border="0" cellpadding="0" cellspacing="1">
    <thead>
      <tr>
        <th class="oid">编号</th>
        <th class="ip">IP/姓名</th>
        <th class="biz_name">商家</th>
        <th class="name">菜名</th>
        <th class="price">单价(元)</th>
        <th class="note">备注</th>
        <th class="time">点餐时间</th>
        <th class="note2">给钱备注</th>
        <th class="operation hack">操作</th>
      </tr>
    </thead>
    <tbody>
<?php
$showFollow = 1;
if (empty($D['data'])) {
    echo '<tr><td colspan="9">未到点餐时间或尚无人点餐！</td></tr>';
} else {
    $statArr = array();
    $menuName = array();
    foreach($D['data'] as $row) {
        $time = date('Y-m-d H:i', $row['time']);
        $menu = $D['menu'][$row['mid']];
        if ($row['ip'] == $D['ip']) {
            $class = ' class="cur"';
            $showFollow = 0;
        } else {
            $class = '';
        }
        $ip_arr = explode('.', $row['ip']);
        $id = intval( $ip_arr[3] );
        if($ip_arr[2] == 1){
            $id += 100;
        }
        if(isset($D['nameArr'][$id])) {
            $row['ip'] = $D['nameArr'][$id];
        }
        if (isset($statArr[$menu['bid']][$row['mid']])) {
            ++$statArr[$menu['bid']][$row['mid']];
        } else {
            $statArr[$menu['bid']][$row['mid']] = 1;
        }
        
        $menuName[$row['mid']][] =  $row['ip'];
        echo <<<EOT
      <tr id="order_{$row['oid']}"{$class}>
        <td>{$id}</td>
        <td>{$row['ip']}</td>
        <td>{$D['biz'][$menu['bid']]['name']}</td>
        <td>{$menu['name']}&nbsp;&nbsp;<a class="followLink" style="display:none;" href="?service=DiancanService&action=doOrderBook&id={$row['mid']}">跟点</a></td>
        <td>{$menu['price']}</td>
        <td><input name="note" type="text" value="{$row['note']}" /></td>
        <td>{$time}</td>
        <td><input name="note2" type="text" value="{$row['note2']}" /></td>
        <td><a class="ajaxLink2" href="?service=DiancanService&action=doUpdateNote&id={$row['oid']}">更新备注</a>&nbsp;|&nbsp;<a class="ajaxLink3" href="?service=DiancanService&action=doUpdateNote2&id={$row['oid']}">给钱备注</a>&nbsp;|&nbsp;<a class="ajaxLink" href="?service=DiancanService&action=doOrderCancel&id={$row['oid']}">取消</a></td>
      </tr>
EOT;
      }
}
?>
    </tbody>
  </table>
<?php
if (!empty($D['data'])) {
?>
  <table class="gTable statList" width="90%" align="center" border="0" cellpadding="0" cellspacing="1" style="margin:0 auto;margin-top:6px;">


<?php
    $allCount = 0;
    $allTotal = 0;
    foreach ($statArr as $bid => $rowArr) {
        echo <<<EOT
    <thead>
      <tr>
        <th colspan="2">商家：{$D['biz'][$bid]['name']}</th>
        <th colspan="3">订餐电话：{$D['biz'][$bid]['phone']}</th>
      </tr>
      <tr>
        <th class="name">菜名</th>
        <th class="count">点餐人</th>
        <th style="width:5%;">单价(元)</th>
        <th style="width:10%;">数量(份)</th>
        <th style="width:10%;">小计(元)</th>
      </tr>
    </thead>
    <tbody>
    <tr style="height:6px;line-height:6px;">
      <td colspan="5">&nbsp;</td>
    </tr>
EOT;
        $subCount = 0;
        $subTotal = 0;
        foreach($rowArr as $mid => $count) {
            $subCount += $count;
            $subTotal += $D['menu'][$mid]['price'] * $count;
            $sum = number_format($D['menu'][$mid]['price'] * $count, 2 , '.', '');

            $menuList = implode('  ', $menuName[$mid]);
            echo <<<EOT
    <tr>
      <td>{$D['menu'][$mid]['name']}</td>
      <td>{$menuList}</td>
      <td>{$D['menu'][$mid]['price']}</td>
      <td>{$count}</td>
      <td>{$sum}</td>
    </tr>
EOT;
        }
        $allCount += $subCount;
        $allTotal += $subTotal;
        if (count($statArr) > 1) {
            $subTotalStr = number_format($subTotal, 2, '.', '');
    echo <<<EOT
    <tr style="font-style:italic;">
      <th colspan="3">小计：</th>
      <th>{$subCount}</th>
      <th>{$subTotalStr}</th>
    </tr>
EOT;
        }
        echo <<<EOT
    <tr style="height:6px;line-height:6px;">
      <td colspan="5">&nbsp;</td>
    </tr>
EOT;
    }
    $allTotalStr = number_format($allTotal, 2, '.', '');
    echo <<<EOT
    <tr>
      <th colspan="3">合计：</th>
      <th>{$allCount}</th>
      <th>{$allTotalStr}</th>
    </tr>
EOT;
}
?>
    </tbody>
  </table>
<?php
$nameStr = '取餐人尚未抽取...';
if ($D['fetch'] === false) {
    if ($D['is_admin']) {
        echo <<<EOT
  <div style="text-align:center; margin-top:6px;"><button style="padding:5px 20px;" onclick="javascript:if(window.confirm('开始抽取？')){location.href='?service=DiancanService&action=randFetchUser'}">随机抽取取餐人</button></div>
EOT;
    }
} else {
    $nameArr = array();
    $ipArr = explode(',', $D['fetch']['ip']);
    foreach ($ipArr as $ip) {
        if ($ip === '') {
           continue;
        }
        $ip_arr = explode('.', $ip);
        $id = intval( $ip_arr[3] );
        if($ip_arr[2] == 1){
            $id += 100;
        }
        if(isset($D['nameArr'][$id])) {
            $nameArr[] = $D['nameArr'][$id];
        } else {
            $nameArr[] = $ip;
        }
    }
    $nameStr = implode(' ', $nameArr);
}
?>
  <table class="gTable gHover fetchList" style="margin:0 auto;margin-top:6px;" width="90%" align="center" border="0" cellpadding="0" cellspacing="1">
    <thead>
      <tr>
        <td>幸运取餐人：<font color="red"><?php echo $nameStr; ?></font></td>
      </tr>
    </thead>
  </table>
</div>
<script type="text/javascript">
function orderCancelCallback(data) {
	if (data.msg) {
		alert(data.msg);
	}
	location.reload();
}
$(function(){
	var showFollow = '<?php echo $showFollow;?>';
	if (showFollow == '1') {
		$('.followLink').show();
	}
	$('.followLink').die('click').live('click', function() {
        var url = $(this).attr('href');
        $.get(url, '', $.ajaxSuccessCallback, 'json');
		location.reload();
		return false;
	});
    $('.ajaxLink2').die('click').live('click', function(){
        var url = $(this).attr('href');
        url += '&note=' + encodeURIComponent($(this).closest('tr').find('input[name=note]').val());
        $.get(url, '', $.ajaxSuccessCallback, 'json');
        return false;
    });
    $('.ajaxLink3').die('click').live('click', function(){
        var url = $(this).attr('href');
        url += '&note2=' + encodeURIComponent($(this).closest('tr').find('input[name=note2]').val());
        $.get(url, '', $.ajaxSuccessCallback, 'json');
        return false;
    });
});
</script>
