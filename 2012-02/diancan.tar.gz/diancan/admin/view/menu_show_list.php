<?php require_once 'header.php'; ?>
<div class="gMain">
  <div class="filterList">
<?php
if (isset($D['filter']['bid'])) {
	echo '<a href="?service=DiancanService&action=showMenuList">不限</a>';
} else {
	echo '<a href="?service=DiancanService&action=showMenuList" class="selected">不限</a>';
}
foreach ($D['biz'] as $bid => $name) {
	if (isset($D['filter']['bid']) && $D['filter']['bid'] == $bid) {
		echo '<a href="?service=DiancanService&action=showMenuList&filter%5Bbid%5D=' . $bid . '" class="selected">' . $name . '</a>';
	} else {
		echo '<a href="?service=DiancanService&action=showMenuList&filter%5Bbid%5D=' . $bid . '">' . $name . '</a>';
	}
}
?>
  </div>
  <table class="gTable gHover menuList" width="100%" border="0" cellpadding="0" cellspacing="1">
    <thead>
      <tr>
        <th class="mid">编号</th>
        <th class="bid">商家</th>
        <th class="name">菜名</th>
        <th class="style">菜系</th>
        <th class="hot">辣度</th>
        <th class="price">单价(元)</th>
        <th class="count">被点次数</th>
        <th class="time">添加时间</th>
        <th class="operation hack">操作</th>
      </tr>
    </thead>
    <tbody>
      <?php
if (empty($D['data'])) {
    echo '<tr><td colspan="9">尚未添加任何菜品！</td></tr>';
} else {
	$styleArr = array(
		0 => '未设置',
		1 => '湘菜',
		2 => '川菜',
		3 => '粤菜',
		4 => '鲁菜',
		5 => '浙菜',
		6 => '徽菜',
		7 => '苏菜',
		8 => '闽菜',
		9 => '其他',
	);
	$hotArr = array(
		0 => '未设置',
		1 => '超级辣',
		2 => '很辣',
		3 => '一般辣',
		4 => '微辣',
		5 => '不辣',
	);
    foreach($D['data'] as $row) {
		$time = date('Y-m-d', $row['time']);
        echo <<<EOT
      <tr>
        <td>{$row['mid']}</td>
        <td>{$D['biz'][$row['bid']]}</td>
        <td>{$row['name']}</td>
        <td>{$styleArr[$row['style']]}</td>
        <td>{$hotArr[$row['hot']]}</td>
        <td>{$row['price']}</td>
        <td id="count_{$row['mid']}">{$row['count']}</td>
        <td>{$time}</td>
        <td><a href="?service=DiancanService&action=showMenuUpdate&id={$row['mid']}">修改</a>&nbsp;|&nbsp;<a class="ajaxLink" href="?service=DiancanService&action=doOrderBook&id={$row['mid']}">点餐</a>&nbsp;|&nbsp;<a class="ajaxLink" href="?service=DiancanService&action=doMenuDelete&id={$row['mid']}">删除</a></td>
      </tr>
EOT;
      }
}
  ?>
    </tbody>
  </table>
  <div class="gPageList">
    <div class="stat">当前 <?php echo $D['page'];?>/<?php echo $D['totalPage'];?> 页 每页 <?php echo $D['pageSize'];?> 条 总共 <?php echo $D['count'];?> 条</div>
    <div class="list">
      <?php
  for($i=1;$i<=$D['totalPage'];++$i) {
      if($i == $D['page']) {
          $str = ' class="cur"';
      } else {
          $str = '';
      }
      echo '<a' . $str . ' href="?service=DiancanService&action=showMenuList&orderColumn='.$D['orderColumn'].'&orderMethod='.$D['orderMethod']. $D['q'] . '&page='.$i.'">'.$i.'</a>';
  }
  ?>
    </div>
  </div>
</div>
<script type="text/javascript">
var orderColumn = '<?php echo $D['orderColumn'];?>';
var orderMethod = '<?php echo $D['orderMethod'];?>';
$(function(){
	$('.menuList thead th').each(function(){
		if ($(this).hasClass('hack')) {
			return true;
		}
		if ($(this).attr('class') == orderColumn) {
			var arrow = orderMethod == 'ASC' ? '↓' : '↑';
			$(this).text($(this).text() + arrow);
		}
		$(this).attr('title', '点击进行排序');
		$(this).click(function(){
			var column = $(this).attr('class');
			if (orderColumn != column) {
				orderColumn = column;
			}
			orderMethod = orderMethod == 'ASC' ? 'DESC' : 'ASC';
			location.href='?service=DiancanService&action=showMenuList&orderColumn='+orderColumn+'&orderMethod='+orderMethod+'<?php echo $D['q'];?>';
		});
	});
});
function orderCallback(data) {
	if (data.msg) {
		alert(data.msg);
	}
	if (data.mid) {
		var obj = $('#count_' + data.mid);
		$count = parseInt(obj.text(), 10);
		++$count;
		obj.html($count);
		location.href = '?service=DiancanService&action=showOrderList';
	}
}
</script>
