<?php require_once 'header.php'; ?>
<div class="gMain">
  <form class="gFrm ajaxSubmit" action="?service=DiancanService&action=doBizAdd" method="post">
    <table class="gTable" width="100%" border="0" cellpadding="0" cellspacing="1">
      <tr>
        <td class="td1">商家名称：</td>
        <td class="td2"><input type="text" id="name" name="name" /></td>
        <td class="td3">说明：商家名称。</td>
      </tr>
      <tr>
        <td class="td1">订餐电话：</td>
        <td class="td2"><input type="text" id="phone" name="phone" /></td>
        <td class="td3">说明：订餐电话，可以填多个。</td>
      </tr>
    </table>
    <table class="gSubmit" width="100%" border="0" cellpadding="0" cellspacing="0">
      <tr>
        <td class="td1">&nbsp;</td>
        <td class="td2"><button type="submit">添加</button>
          <button class="gGoBack" type="button">返回</button></td>
        <td class="td3">&nbsp;</td>
      </tr>
    </table>
  </form>
</div>
<script type="text/javascript">
$(function(){
	$('#name').focus();
});
</script>
