<?php require_once 'header.php'; ?>
<div class="gMain">
    <form method="post">
  <table class="gTable gHover " width="100%" border="0" cellpadding="0" cellspacing="1">
      <?php
      if($D['is_admin'] == 1){
      ?>
      <tr>
          <td colspan="10">增加员工  : 员工号<input type="text" name="user[u_no]">姓名<input type="text" name="user[u_name]" > <button type="submit">确定</button></td>
      </tr>
       <tr>
          <td colspan="10">删除员工  : 员工号<input type="text" name="del"> <button type="submit" onclick="return window.confirm('确定删除？');">确定</button></td>
      </tr>
      <?php
      }
      ?>
    <thead>
      <tr>
        <th class="oid" colspan="10">员工编号  :  员工号 IP/姓名</th>
      </tr>
    </thead>
    <tbody>
        <tr>
<?php
ksort( $D['nameArr'] );
$curCount = count($D['nameArr']);
for($i = 0; $i < 5 - $curCount % 5; ++$i) {
    $D['nameArr'][] = '<font color="gray">招募中...</font>';
}
$i =0;
    foreach($D['nameArr'] as $no => $name) {
        if($i > 0 && $i % 5 == 0){
            echo '</tr><tr>';
        }
        $i++;
        echo <<<EOT
        <td style="background-color: #F9F2F2;">{$no}</td><td><b>{$name}</b></td>
EOT;
      }
?>
            </tr>
    </tbody>
  </table>
        </form>
<script type="text/javascript">
function orderCancelCallback(data) {
	if (data.msg) {
		alert(data.msg);
	}
	location.reload();
}
</script>