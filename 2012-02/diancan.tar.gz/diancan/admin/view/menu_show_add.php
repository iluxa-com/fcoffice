<?php require_once 'header.php'; ?>
<div class="gMain">
  <form class="gFrm ajaxSubmit" action="?service=DiancanService&action=doMenuAdd" method="post">
    <table class="gTable" width="100%" border="0" cellpadding="0" cellspacing="1">
      <tr>
        <td class="td1">菜名：</td>
        <td class="td2"><input type="text" id="name" name="name" /></td>
        <td class="td3">说明：菜名。</td>
      </tr>
      <tr>
        <td class="td1">单价：</td>
        <td class="td2"><input type="text" id="price" name="price" maxlength="6" class="positiveFloatFilter" /></td>
        <td class="td3">说明：单价(元)。</td>
      </tr>
      <tr>
        <td class="td1">商家：</td>
        <td class="td2" style="text-align:left;padding-left:6px;"><select id="bid" name="bid">
            <option value="0">－－请选择－－</option>
<?php
foreach ($D['biz'] as $row) {
	echo '<option value="'. $row['bid'] . '">' . $row['name'] . '</option>';
}
?>
          </select></td>
        <td class="td3">说明：供菜商家。<a href="?service=DiancanService&action=showBizAdd">新增商家</a></td>
      </tr>
      <tr>
        <td class="td1">菜系：</td>
        <td class="td2" style="text-align:left;padding-left:6px;"><select id="style" name="style">
            <option value="0">－－请选择－－</option>
            <option value="1">湘菜</option>
            <option value="2">川菜</option>
            <option value="3">粤菜</option>
            <option value="4">鲁菜</option>
            <option value="5">浙菜</option>
            <option value="6">徽菜</option>
            <option value="7">苏菜</option>
            <option value="8">闽菜</option>
            <option value="9">其他</option>
          </select></td>
        <td class="td3">说明：菜系。</td>
      </tr>
      <tr>
        <td class="td1">辣度：</td>
        <td class="td2" style="text-align:left;padding-left:6px;"><select id="hot" name="hot">
            <option value="0">－－请选择－－</option>
            <option value="1">超级辣</option>
            <option value="2">很辣</option>
            <option value="3">一般辣</option>
            <option value="4">微辣</option>
            <option value="5">不辣</option>
          </select></td>
        <td class="td3">说明：辣度。</td>
      </tr>
    </table>
    <table class="gSubmit" width="100%" border="0" cellpadding="0" cellspacing="0">
      <tr>
        <td class="td1">&nbsp;</td>
        <td class="td2"><button type="submit">添加</button>
          <button class="gGoBack" type="button">返回</button></td>
        <td class="td3">&nbsp;</td>
      </tr>
    </table>
  </form>
</div>
<script type="text/javascript">
$(function(){
	$('#name').focus();
});
</script>
