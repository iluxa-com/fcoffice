<div class="gNav">饭后点餐系统&nbsp;&gt;&gt;&nbsp;
<?php
$menu_list = array(
    '添加菜品'  => array( 'url'=>'?service=DiancanService&action=showMenuAdd&menu_id=1' , 'menu_id'=>1),
    '每周菜单设定'  => array( 'url'=>'?service=DiancanService&action=week&menu_id=6' , 'menu_id'=>6),
    '菜品列表'  => array( 'url'=>'?service=DiancanService&action=showMenuList&menu_id=2', 'menu_id'=>2),
    '点餐列表'  => array( 'url'=>'?service=DiancanService&action=showOrderList&menu_id=3', 'menu_id'=>3),
    '点餐须知'  => array( 'url'=>'?service=DiancanService&action=showNotice&menu_id=4', 'menu_id'=>4),
    '员工编码'  => array( 'url'=>'?service=DiancanService&action=showUser&menu_id=5', 'menu_id'=>5),
);

foreach($menu_list as $k=>$v){
    if( !empty($_GET['menu_id']) && $_GET['menu_id']== $v['menu_id']){
        echo $k.'&nbsp;&nbsp;&nbsp;&nbsp;';
    }else{
        echo '<a href="'.$v['url'].'">'.$k.'</a>&nbsp;&nbsp;&nbsp;&nbsp;';
    }
}
?>目前系统时间：<?php echo date('H:i:s'); ?>
</div>