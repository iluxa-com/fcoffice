<?php
require_once 'header.php'; 
function htmlSelect($name,$arr,$valkey=null){
    $htm = "<select name=$name >";
    if(!empty($arr)){
        foreach ($arr as $key=>$val){
            $htm .= "<option value=$key ";
            if(!empty($valkey) && $valkey == $key){
                $htm .= " selected ";
            }
            
            $htm .= " >$val</option>";
        }
    }
    $htm .= "</select>";
    return $htm;
}
?>
<div class="gMain">
  <table class="gTable gHover orderList" width="100%" border="0" cellpadding="0" cellspacing="1">
    <thead>
      <tr>
        <th class="oid">星期一</th>
        <th class="oid">星期二</th>
        <th class="oid">星期三</th>
        <th class="oid">星期四</th>
        <th class="oid">星期五</th>
<th class="oid">6</th>
<th class="oid">7</th>
      </tr>
    </thead>
    <tbody>
        <tr >
<?php
    for($i=1;$i<8;$i++) {
        $class = $i == $D['week']   ?   'style="background: #DEDEBE" '  :   '';
        echo '<td '.$class.'>'.$D['bid'][$D['week_biz'][$i]].'</td>';
    }

    if($D['admin'] == 1){
echo <<<EOT
            </tr>
            <tr><td colspan=7>&nbsp;</td></tr>
            <tr><td colspan=7>&nbsp;</td></tr>
            <form action="" method="post">
            <tr>
EOT;
        for($i=1;$i<8;$i++) {
            $class = $i == $D['week']   ?   'style="background: #DEDEBE" '  :   '';
            echo '<td '.$class.'>'.htmlSelect("week[$i]", $D['bid'], $D['week_biz'][$i]).'</td>';
        }
echo <<<EOT
            </tr>
            <tr><td colspan=7>&nbsp;</td></tr>
            <tr><td colspan=7>&nbsp;<button type="submit" onclick="return window.confirm('确定保存？');">录入</button></td></tr>
            </form>
            <tr><td colspan=7>&nbsp;</td>
EOT;
    }
?>
            </tr>
    </tbody>
  </table>
