<?php
	$uname = '10170'; //工号
	$password = ''; //密码
	$fetion_remind = true; //是否使用飞信提醒
	$tel = '13714681456'; //手机号
	$fetion_psw = '7340985cxm'; //飞信密码
	