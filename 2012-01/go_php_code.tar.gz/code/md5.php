<?php
	echo md5("admin");
	echo "<br>--------------<br/>";
	echo "25a77273506b52423b12891c19d4f9ff";