	<?php
	phpinfo();
	echo "hello";
