<?php
	phpinfo();
