<?php 
	// ensure this file is being included by a parent file
	if( !defined( '_JEXEC' ) && !defined( '_VALID_MOS' ) ) die( 'Restricted access' );
	$GLOBALS["users"]=array(
	array("admin","25a77273506b52423b12891c19d4f9ff","/home/dotcloud/current","http://localhost",1,"",7,1),
); 
?>