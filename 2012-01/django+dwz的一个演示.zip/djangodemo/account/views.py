#!usr/bin/env python
#coding: utf-8
from django.core.urlresolvers import reverse
from django.http import HttpResponse, HttpResponseRedirect
from django.shortcuts import render_to_response, get_object_or_404
from django.template import RequestContext
from django.contrib import messages
from django.contrib.auth.models import User
from django.contrib.auth import authenticate, login as auth_login ,logout as auth_logout
from django.utils.translation import ugettext_lazy as _
from django.utils import simplejson
from django.core.paginator import Paginator, InvalidPage, EmptyPage

def index(request):
    users = User.objects.order_by('-id')
    paginator = Paginator(users, 10)
    page = request.POST.get('pageNum',1)
    try:
        users = paginator.page(page)
    except (EmptyPage, InvalidPage):
        users = paginator.page(paginator.num_pages)
    return render_to_response('account/welcome.html',{'users':users, 'currentPage':page, 'numPerPage':5})

def register(request):

    if request.POST:
        username = request.POST.get('username',None)
        password = request.POST.get('password',None)
        email = request.POST.get('email',None)
        '''验证重复帐号名'''
        usernames = User.objects.filter(username__iexact=username)
        '''验证重复email'''
        emails = User.objects.filter(email__iexact=email)
        if  usernames:
            return HttpResponse(simplejson.dumps({"status":201, "statusCode":201, "navTabId":request.POST.get('navTabId','accountindex'), "callbackType":request.POST.get('callbackType',None), "message":u'用户名已经存在不能添加', "info":u'用户名已经存在不能添加',"result":u'用户名已经存在不能添加'}), mimetype='application/json')
        if  emails:
            return HttpResponse(simplejson.dumps({"status":201, "statusCode":201, "navTabId":request.POST.get('navTabId','accountindex'), "callbackType":request.POST.get('callbackType',None), "message":u'EMAIL已经存在不能添加', "info":u'EMAIL已经存在不能添加',"result":u'EMAIL已经存在不能添加'}), mimetype='application/json')
        if password != None and password != '':
            user = User(username=username, password=password, email=email)
        else:
            user = User(username=username, email=email)
        user.save()
        return HttpResponse(simplejson.dumps({"status":1, "statusCode":1, "navTabId":request.POST.get('navTabId','accountindex'), "callbackType":request.POST.get('callbackType',None), "message":u'添加成功', "info":u'添加成功',"result":u'添加成功'}), mimetype='application/json')
    return render_to_response('account/register.html')   

def edit(request, id):
    user=get_object_or_404(User,pk=int(id))
    if request.POST:
        user.username = request.POST.get('username',None)
        user.password = request.POST.get('password',None)
        user.email = request.POST.get('email',None)
        user.save()
        return HttpResponse(simplejson.dumps({"status":1, "statusCode":1, "navTabId":request.POST.get('navTabId','accountindex'), "callbackType":request.POST.get('callbackType',None), "message":u'编辑成功', "info":u'编辑成功',"result":u'编辑成功'}), mimetype='application/json')
    return render_to_response('account/edit.html', {'user': user})
    
        
def login(request):
    '''登陆视图'''
    pass
    #template_var={}
    #form = LoginForm()    
    #if request.method == 'POST':
    #    form=LoginForm(request.POST.copy())
    #    if form.is_valid():
    #        _login(request,form.cleaned_data["username"],form.cleaned_data["password"])
    #        return HttpResponseRedirect(reverse("accounts_index"))
    #template_var["form"]=form        
    #return render_to_response("account/login.html",template_var,context_instance=RequestContext(request))
    
def _login(request,username,password):
    '''登陆核心方法'''
    ret=False
    user=authenticate(username=username,password=password)
    if user:
        if user.is_active:
            auth_login(request,user)
            ret=True
        else:
            messages.add_message(request, messages.INFO, _(u'用户没有激活'))
    else:
        messages.add_message(request, messages.INFO, _(u'用户不存在'))
    return ret
    
def logout(request):
    '''注销视图'''
    auth_logout(request)
    return HttpResponseRedirect(reverse('accounts_index'))

def selecteddelete(request):
    pass