#!usr/bin/env python
#coding: utf-8
from django.conf.urls.defaults import *
from django.conf import settings

urlpatterns = patterns('',
    url(r'^$', 'account.views.index',name="accounts_index"),
    url(r'^index/$', 'account.views.index', name="accounts_index"),
    url(r'^register/$', 'account.views.register',name="accounts_register"),
    url(r'^edit/(?P<id>\d+)/$', 'account.views.edit',name="accounts_edit"),
    url(r'^login/$', 'account.views.login',name="accounts_login"),
    url(r'^selecteddelete/$', 'account.views.selecteddelete',name="accounts_selecteddelete"),
    url(r'^logout/$', 'account.views.logout',name="accounts_logout"),
)