#!usr/bin/env python
#coding: utf-8
from django.forms import ModelForm
from models import Blog

class AddForm(ModelForm):
    class Meta:
        model=Blog