#!usr/bin/env python
#coding: utf-8
from django.db import models

class Blog(models.Model):
    title      = models.CharField(u"标题",max_length=60)
    content    = models.TextField(u"正文")
    created_at = models.DateTimeField(u"建立时间",auto_now_add=True)
    updated_at = models.DateTimeField(u"修改时间",auto_now=True)
    
    def __uncode__(self):
        return self.title
    
    class Meta:
        ordering = ['-updated_at','-created_at']

class User(models.Model):
    username    = models.CharField(u"用户名", max_length = 60)
    password    = models.CharField(u"密码", max_length = 32)
    email       = models.EmailField(u"电子邮箱", max_length = 100)
    create_time = models.DateTimeField(auto_now = True, auto_now_add = True)
    
    def __uncode__(self):
        return self.username
    
    class Meda:
        ordering = ['-create_time']