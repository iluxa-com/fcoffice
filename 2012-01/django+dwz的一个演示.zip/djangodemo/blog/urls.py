#!usr/bin/env python
#coding: utf-8
from django.conf.urls.defaults import *
from django.conf import settings

urlpatterns = patterns('',
    url(r'^index/$', 'blog.views.index',name="blog_index"),
    url(r'^add/$', 'blog.views.add',name="blog_add"),
    url(r'^list/$', 'blog.views.list',name="blog_list"),
    url(r'^update-(?P<id>\d+)/$', 'blog.views.update',name="blog_update"),
    url(r'^delete-(?P<id>\d+)/$', 'blog.views.delete',name="blog_delete"),
)