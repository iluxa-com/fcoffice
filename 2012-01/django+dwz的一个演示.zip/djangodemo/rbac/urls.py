#!usr/bin/env python
#coding: utf-8
from django.conf.urls.defaults import *
from django.conf import settings

urlpatterns = patterns('',
    url(r'^$', 'rbac.views.index',name="rbac_index"),
    url(r'^index/$', 'rbac.views.index', name="rbac_index"),
    url(r'^add/$', 'rbac.views.add',name="rbac_add"),
    url(r'^edit/(?P<id>\d+)/$', 'rbac.views.edit',name="rbac_edit"),
    url(r'^delete/(?P<id>\d+)/$', 'rbac.views.delete',name="rbac_delete"),
)