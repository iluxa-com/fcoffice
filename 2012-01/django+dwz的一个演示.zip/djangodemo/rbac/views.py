#!usr/bin/env python
#coding: utf-8
from django.shortcuts import render_to_response,get_object_or_404
from django.http import HttpResponseRedirect
from django.core.urlresolvers import reverse
from models import User
from forms import UserForm

def index(request):
    users = User.objects.order_by('-create_time')
    return render_to_response('rbac/index.html', {'users': users})

def add(request):
    if request.POST:
        form = UserForm(request.POST)
        if form.is_valid():
            user = form.save()
            user.save()
            return HttpResponseRedirect(reverse('rbac_index'))
    return render_to_response('rbac/add.html', {'form': UserForm()})
def edit(request, id):
    user = get_object_or_404(User, pk=id)
    if request.method == 'POST':
        form = UserForm(request.POST, instance=user)
        if form.is_valid():
            user.form.save()
            user.save()
            return HttpResponseRedirect(reverse('rbac_index'))
    return render_to_response('rbac/edit.html', {'form':UserForm(instance = user)})
def delete(request, id):
    user = get_object_or_404(User, pk=id)
    if user:
        user.delete()
        return HttpResponseRedirect(reverse('rbac_index'))
