#!/usr/bin/env python
#coding: utf-8
from django.db import models
from django.utils.hashcompat import md5_constructor

class User(models.Model):
    account         = models.CharField(u'帐号', max_length = 64)
    username        = models.CharField(u'姓名', max_length = 50)
    password        = models.CharField(u'密码', max_length = 32)
    last_login_time = models.DateTimeField(u'最后登录时间',auto_now =False, editable=False)
    email           = models.EmailField(u'电子邮箱')
    create_time     = models.DateTimeField(u'添加时间',auto_now = True, editable=False) 
