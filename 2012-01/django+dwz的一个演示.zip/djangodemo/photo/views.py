#!usr/bin/env python
#coding: utf-8
from django.http import HttpResponse, HttpResponseRedirect
from django.shortcuts import render_to_response,get_object_or_404
from django.template import RequestContext
from django.template.context import RequestContext
from django.core.urlresolvers import reverse
from django.utils import simplejson
from django.conf.urls.defaults import *
from django.conf import settings
import os,time
from django.core.paginator import Paginator, InvalidPage, EmptyPage
from models import Photo

def index(request):
    photos = Photo.objects.order_by('-id')
    paginator = Paginator(photos, 10)
    page = request.POST.get('pageNum',1)
    try:
        photos = paginator.page(page)
    except (EmptyPage, InvalidPage):
        photos = paginator.page(paginator.num_pages)
    return render_to_response('photo/index.html',context_instance=RequestContext(request, {'photo':photos, 'currentPage':page, 'numPerPage':5}	))

def add(request):
    file = request.FILES.get('uploadfile', None)
    if file:
        name = request.POST['name']
        str_time = time.strftime('%Y-%m-%d-%H%M%S',time.localtime(time.time()))
        fname = file.name;
        fname = str_time + fname[fname.rfind('.'):]
        of = open(settings.FILE_UPLOAD_TEMP_DIR+fname, 'wb+')
        for chunk in file.chunks():
            of.write(chunk)
        of.close()
        photo = Photo(name=name, images_path=fname)
        photo.save()
        return HttpResponse(simplejson.dumps({"statusCode":200, "navTabId":request.POST.get('navTabId','photoindex'), "callbackType":request.POST.get('callbackType','closeCurrent'), "message":u'添加成功'}), mimetype='text/html')
        #return HttpResponseRedirect(reverse("index"))
    else:
        return render_to_response('photo/add.html')
def edit(request,id):
    photo=get_object_or_404(Photo,pk=int(id))
    if request.POST:
        photo.name = request.POST.get('name',photo.name)
        file = request.FILES.get('uploadfile', None)
        if file:
            str_time = time.strftime('%Y-%m-%d-%H%M%S',time.localtime(time.time()))
            fname = file.name;
            fname = str_time + fname[fname.rfind('.'):]
            of = open(settings.FILE_UPLOAD_TEMP_DIR+fname, 'wb+')
            for chunk in file.chunks():
                of.write(chunk)
            of.close()
            photo.images_path = fname
        photo.save()
        return HttpResponse(simplejson.dumps({"statusCode":200, "navTabId":request.POST.get('navTabId','photoindex'), "callbackType":request.POST.get('callbackType','closeCurrent'), "message":u'编辑成功'}), mimetype='text/html')
    else:
	    return render_to_response('photo/edit.html', context_instance=RequestContext(request, {'photo':photo}))

def search(request):
    if 'q' in request.GET and request.GET['q']:
        q = request.GET['q']
        photos = Photo.objects.filter(title_icontains = q)
        return render_to_response('photo/index.html', {'photos':photos},{'q':q})
    else:
        return render_to_response('photo/index.html')
    
def selecteddelete(request):
    ids = request.POST.get('ids', None)
    if ids:
        Photo.objects.extra(where=['id IN ('+ ids +')']).delete() 
        return HttpResponse(simplejson.dumps({"statusCode":200, "navTabId":request.POST.get('navTabId','photoindex'), "callbackType":request.POST.get('callbackType',''), "message":u'选中项删除成功'}), mimetype='application/json')

def delete(request,id):
    photo = Photo.objects.get(id=id)
    if os.path.exists(settings.FILE_UPLOAD_TEMP_DIR+photo.images_path):
        os.remove(settings.FILE_UPLOAD_TEMP_DIR+photo.images_path)
    photo.delete()
    return HttpResponse(simplejson.dumps({"statusCode":200, "navTabId":request.POST.get('navTabId','photoindex'), "callbackType":request.POST.get('callbackType',''), "message":u'删除成功'}), mimetype='application/json')
     
        
        