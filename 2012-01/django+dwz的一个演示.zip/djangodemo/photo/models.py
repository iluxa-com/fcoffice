#!usr/bin/env python
#coding: utf-8
from django.db import models

class Photo(models.Model):
    name = models.CharField(u'相片名称', max_length = 80)
    images_path = models.CharField(max_length = 250)
    create_date = models.DateTimeField(auto_now = True)
    
    def __unicode__(self):
        return self.name