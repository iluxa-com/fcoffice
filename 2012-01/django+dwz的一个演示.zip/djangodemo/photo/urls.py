#!usr/bin/env python
#coding: utf-8
from django.conf.urls.defaults import *
from django.conf import settings

urlpatterns = patterns('',
    url(r'^$', 'photo.views.index',name="photo_index"),
    url(r'^index/$', 'photo.views.index', name="photo_index"),
    url(r'^add/$', 'photo.views.add',name="photo_add"),
    url(r'^edit/(?P<id>\d+)/$', 'photo.views.edit',name="photo_edit"),
    url(r'^delete/(?P<id>\d+)/$', 'photo.views.delete',name="photo_delete"),
    url(r'^selecteddelete/$', 'photo.views.selecteddelete',name="photo_selecteddelete"),
    url(r'^search/$', 'photo.views.search',name="photo_search"),
)