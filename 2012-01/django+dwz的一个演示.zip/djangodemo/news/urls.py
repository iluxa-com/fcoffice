#!usr/bin/env python
#coding: utf-8
from django.conf.urls.defaults import *
from django.conf import settings

urlpatterns = patterns('',
    url(r'^$', 'news.views.index',name="news_index"),
    url(r'^index/$', 'news.views.index', name="news_index"),
    url(r'^add/$', 'news.views.add',name="news_add"),
    url(r'^edit/(?P<id>\d+)/$', 'news.views.edit',name="news_edit"),
	url(r'^content/(?P<id>\d+)/$', 'news.views.content',name="news_content"),
    url(r'^delete/(?P<id>\d+)/$', 'news.views.delete',name="news_delete"),
    url(r'^selecteddelete/$', 'news.views.selecteddelete',name="news_selecteddelete"),
    url(r'^search/$', 'news.views.search',name="news_search"),
)