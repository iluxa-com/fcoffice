#!usr/bin/env python
#coding: utf-8
from django.http import HttpResponse, HttpResponseRedirect
from django.shortcuts import render_to_response,get_object_or_404
from django.template import RequestContext
from django.core.urlresolvers import reverse
from django.utils import simplejson
from django.core.paginator import Paginator, InvalidPage, EmptyPage
from models import Author,News

def index(request):
    news = News.objects.order_by('-id')
    paginator = Paginator(news, 10)
    page = request.POST.get('pageNum',1)
    try:
        news = paginator.page(page)
    except (EmptyPage, InvalidPage):
        news = paginator.page(paginator.num_pages)
    return render_to_response('news/index.html',{'news':news, 'currentPage':page, 'numPerPage':5})

def add(request):
    if request.POST:
        title = request.POST.get('title',None)
        keywords = request.POST.get('keywords',None)
        description = request.POST.get('description',None)
        content = request.POST.get('content',None)
        author = Author.objects.filter(id=1)[0]
        news = News(title=title, keywords=keywords, description=description, content=content,author = author)
        news.save()
        return HttpResponse(simplejson.dumps({"statusCode":200, "navTabId":request.POST.get('navTabId','newsindex'), "callbackType":request.POST.get('callbackType','closeCurrent'), "message":u'添加成功'}), mimetype='application/json')
        #return HttpResponseRedirect(reverse("index"))
    else:
        return render_to_response('news/add.html')
def edit(request,id):
    news=get_object_or_404(News,pk=int(id))
    if request.POST:
        news.title = request.POST.get('title',None)
        news.keywords = request.POST.get('keywords',None)
        news.description = request.POST.get('description',None)
        news.content = request.POST.get('content',None)
        news.author = Author.objects.filter(id=1)[0]
        news.save()
        return HttpResponse(simplejson.dumps({"statusCode":200, "navTabId":request.POST.get('navTabId','newsindex'), "callbackType":request.POST.get('callbackType','closeCurrent'), "message":u'编辑成功'}), mimetype='application/json')
    return render_to_response('news/edit.html', {'news': news})
def content(request,id):
    new=get_object_or_404(News,pk=int(id))
    return render_to_response('news/content.html', {'new': new})
def search(request):
    if 'q' in request.GET and request.GET['q']:
        q = request.GET['q']
        news = News.objects.filter(title_icontains = q)
        return render_to_response('news/index.html', {'news':news},{'q':q})
    else:
        return render_to_response('news/index.html')
    
def selecteddelete(request):
    ids = request.POST.get('ids', None)
    if ids:
        News.objects.extra(where=['id IN ('+ ids +')']).delete() 
        return HttpResponse(simplejson.dumps({"statusCode":200, "navTabId":request.POST.get('navTabId','newsindex'), "callbackType":request.POST.get('callbackType',''), "message":u'选中项删除成功'}), mimetype='application/json')

def delete(request,id):
    News.objects.get(id=id).delete()
    return HttpResponse(simplejson.dumps({"statusCode":200, "navTabId":request.POST.get('navTabId','newsindex'), "callbackType":request.POST.get('callbackType',''), "message":u'删除成功'}), mimetype='application/json')
     
        
        