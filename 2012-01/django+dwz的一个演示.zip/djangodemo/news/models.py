#!usr/bin/env python
#coding: utf-8
from django.db import models

class Author(models.Model):
    username = models.CharField(u'作者', max_length = 60)
    address  = models.CharField(u'地址', max_length = 250)
    
    def __unicode__(self):
        return self.username
    
class News(models.Model):
    title       = models.CharField(u'标题', max_length = 120)
    keywords    = models.CharField(u'关键字', max_length = 100)
    description = models.CharField(u'简介', max_length = 250)
    content     = models.TextField(u'内容')
    create_date = models.DateTimeField(u'添加时间', auto_now = True)
    update_date = models.DateTimeField(u'修改时间', auto_now = True)
    author      = models.ForeignKey(Author)
    
    def __unicode__(self):
        return self.title